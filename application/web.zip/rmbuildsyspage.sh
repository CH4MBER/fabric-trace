rm src/router/index.js
cp src/router/index_temp.js src/router/index.js
